#include <iostream>
#include <fstream>
#include "QueueList.h"
#include "StackList.h"
#include "task1_backend.h"
#include "task2_backend.h"
using namespace std;

/////////// Helper Methods ////////////////

template <class T>
void stack_input(StackList<T>& st) {
    int size;
    cout << "Enter size: ";
    cin >> size;

    if (size <= 0)
        return;
    cout << "Enter Elements: ";
    T input;
    while (size--) {
        cin >> input;
        st.push(input);
    }
}

template <class T>
void queue_input(QueueList<T>& q) {
    int size;
    cout << "Enter size: ";
    cin >> size;

    if (size <= 0)
        return;
    cout << "Enter Elements: ";
    T input;
    while (size--) {
        cin >> input;
        q.enqueue(input);
    }
}

bool ReadFileLines(string path, QueueList<string>& lines) {
	ifstream inFile(path);

	if (inFile.fail()) {
		cout << "\n\nERROR: Can't open the file\n\n";
		return false;
	}

	string line;
	while (getline(inFile, line)) {
		if (line.size() == 0)
			continue;
		lines.enqueue(line);
	}

	inFile.close();
    return true;
}

QueueList<string> SplitString(string s, string delimiter = ",") {
	QueueList<string> strs; 

	int pos = 0;
	string substr;
	while ((pos = (int) s.find(delimiter)) != -1) {
		substr = s.substr(0, pos);
		strs.enqueue(substr);
		s.erase(0, pos + delimiter.length());
	}
	strs.enqueue(s);
	return strs;
}

//////////////////////////////////////////

int entry_menu() {
    int choice = -1;
    while (choice == -1) {
        cout << "\nTasks Menu:\n"
            << "1) Task 1\n"
            << "2) Task 2\n"
            << "3) Bonus\n"
            << "4) Exit\n";

        cout << "\nEnter your menu choice [1 - 4]: ";
        cin >> choice;

        if (!(1 <= choice && choice <= 4)) {
            cout << "Invalid choice. Try again\n";
            choice = -1;	// loop keep working
        }
    }
    return choice;
}

int task1_menu() {
    int choice = -1;
    while (choice == -1) {
        cout << "\nTask 1 Menu:\n"
            << "1) Add a Car\n"
            << "2) Remove a Car\n"
            << "3) Search for a Car by Make and Model\n"
            << "4) Display all Cars\n"
            << "5) Return To The Main Menu\n";

        cout << "\nEnter your menu choice [1 - 5]: ";
        cin >> choice;

        if (!(1 <= choice && choice <= 5)) {
            cout << "Invalid choice. Try again\n";
            choice = -1;	// loop keep working
        }
    }
    return choice;
}

int task2_menu() {
    int choice = -1;
    while (choice == -1) {
        cout << "\nTask 2 Menu:\n"
            << "1) Copy a Stack\n"
            << "2) Convert Decimal to Another Base\n"
            << "3) Subtract 2 Big Integers\n"
            << "4) Move Nth Element to Front in a Queue of Strings\n"
            << "5) Reverse Elements of a Queue\n"
            << "6) Return To The Main Menu\n";

        cout << "\nEnter your menu choice [1 - 6]: ";
        cin >> choice;

        if (!(1 <= choice && choice <= 6)) {
            cout << "Invalid choice. Try again\n";
            choice = -1;	// loop keep working
        }
    }
    return choice;
}

void task1_execution(SortedUniL& cars) {
    while (true) {
        int choice = task1_menu();
        string make, model;

        if (choice <= 3) {
            cout << "Make and Model: ";
            cin >> make >> model;
        }

        if (choice == 1) // Add a Car
            cars.insert(make, model);

        else if (choice == 2) // Remove a Car
            cars.remove(make, model);

        else if (choice == 3) // Search for a Car by Make and Model
            cars.search(make, model);

        else if (choice == 4) // Display all Cars
            cars.print();

        else // Return To The Main Menu
            break;
    }
}

template <class T>
void task2_execution() {
    while (true) {
        int choice = task2_menu();

        if (choice == 1) { // Copy a Stack
            StackList<T> st1, st2;
            cout << "Enter Stack 1 Data \n";
            stack_input(st1);

            copyStack(st1, st2);
            cout << "Stack 1 has been successfully copied\n";
            
            cout << "Stack 1 Elements: ";
            while (!st1.isEmpty())
                cout << st1.pop() << " ";
            cout << "\n";

            cout << "Stack 2 Elements: ";
            while (!st2.isEmpty())
                cout << st2.pop() << " ";
            cout << "\n";
        }

        else if (choice == 2) { // Convert Decimal to Another Base
            int decimal, base;
            cout << "Enter a Decimal Number and a Base: ";
            cin >> decimal >> base;
            string res = convertToNS(decimal, base);
            cout << "Output: " << res << "\n";
        }

        else if (choice == 3) { // Subtract 2 Big Integers
            string num1, num2;
            cout << "Enter Two Integer Numbers: ";
            cin >> num1 >> num2;
            string res = subtractLargeInts(num1, num2);
            cout << "Output: " << res << "\n";
        }

        else if (choice == 4) { // Move Nth Element to Front in a Queue of Strings
            QueueList<T> q;
            cout << "Enter Queue Data \n";
            queue_input(q);

            int idx;
            cout << "Enter Index(1-based index) for the Nth Element: ";
            cin >> idx;

            while (!moveNthElem(q, idx)) {
                cout << "invalid index !! .. try again: ";
                cin >> idx;
            }

            cout << "The Element with Index " << idx << "has been moved to the front successfully\n";
            cout << "Queue Elements After Update: ";
            while (!q.isEmpty())
                cout << q.front() << " ", q.dequeue();
            cout << "\n";
        }
        
        else if (choice == 5) { // Reverse Elements of a Queue
            QueueList<T> q;
            cout << "Enter Queue Data \n";
            queue_input(q);

            reverseQueue(q);

            cout << "Queue has been reversed successfully\n";
            cout << "Queue Elements After Update: ";
            while (!q.isEmpty())
                cout << q.front() << " ", q.dequeue();
            cout << "\n";
        }

        else  // Return To The Main Menu
            break;
    }
}

void bonus_execution() {
    QueueList<string> lines;
    string path;
    cout << "Enter File Name with its Extension: ";
    cin >> path;

    if (!ReadFileLines(path, lines))
        return;

    int lines_number = stoi(lines.front()); // the 1st line is the lines number
    lines.dequeue();
    int counter = 1;
    while (lines_number--) {
        QueueList<string> substrs = SplitString(lines.front()); // substrs[0] = author , substrs[1] = title 
        lines.dequeue();

        string author = substrs.front();
        substrs.dequeue();

        string title = substrs.front();
        substrs.dequeue();

        cout << "Book " << counter++ << " => Author: " << author << " , Title: " << title << "\n";
    }
}


void run() {
    SortedUniL cars; // data will be saved even if the user enters Exit from Task 1
    while (true) {
        int choice = entry_menu();
        
        if (choice == 1) // task 1
            task1_execution(cars);

        else if (choice == 2) // task 2
            task2_execution<int>(); // we can use any data type instead of "int", 
                                    // but let's use "int" as our desired data type

        else if (choice == 3) // Bonus Part
            bonus_execution();

        else { // End The Program
            cout << "BYE ..\n";
            break;
        }
    }
}


int main() {

    run(); // run the program

    return 0;
}

