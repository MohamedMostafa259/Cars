#ifndef TASK1_BACKEND_H
#define TASK1_BACKEND_H

#include <iostream>
using namespace std;

class CarNode {
public:
    string make;
    string model;
    int carsNum{};
    CarNode* next;
    CarNode() : next(0) {}
    CarNode(const string& mk, const string& mod, CarNode* in = 0) : make(mk), model(mod), next(in) {
        carsNum = 1;
    }
};

class SortedUniL {
private:
    CarNode* head {};
    CarNode* tail {};
public:

    void insert(const string& make, const string& model) {
        string makeLower = make;
        string modelLower = model;
        for (char & c: makeLower) { // we use '&' to change the original letter in the "makeLower" string 
            c = tolower(c); 
        }
        for (char & c: modelLower) { // we use '&' to change the original letter in the "modelLower" string 
            c = tolower(c);
        }
        if (!head) // empty
            head = tail = new CarNode(makeLower, modelLower);

        else {
            CarNode* cur, *prv;
            for (cur = head, prv = nullptr; cur; prv = cur, cur = cur->next) {
                if (cur->make == makeLower && cur->model == modelLower) {
                    cur->carsNum++;
                    return;
                }
                else if (makeLower < cur->make || (cur->make == makeLower && modelLower < cur->model)) {
                    CarNode* node = new CarNode(makeLower, modelLower);
                    if (prv) prv->next = node;
                    else head = node;
                    node->next = cur;
                    return;
                }
            }
            prv->next = tail = new CarNode(makeLower, modelLower); // if NOT inserted, makeLower a new tail
        }
    }

    void search(const string &make, const string &model) {
        string makeLower = make;
        string modelLower = model;
        for (char & c: makeLower) { // we use '&' to change the original letter in the "makeLower" string 
            c = tolower(c);
        }
        for (char & c: modelLower) { // we use '&' to change the original letter in the "modelLower" string 
            c = tolower(c);
        }
        CarNode *temp = head;
        while (temp != nullptr) {

            if (temp->make == makeLower && temp->model == modelLower) {
                cout << "Number of cars found of this make and model: " << temp->carsNum << endl;
                return;
            }
            temp = temp->next;
        }
        cout << "Car not found!" << endl;
    }

    void remove(const string& make, const string& model) {
        string makeLower = make;
        string modelLower = model;
        for (char & c: makeLower) { // we use '&' to change the original letter in the makeLower" string 
            c = tolower(c); 
        }
        for (char & c: modelLower) { // we use '&' to change the original letter in the "modelLower" string 
            c = tolower(c);
        }
        CarNode *current = head;
        CarNode *prev = nullptr;

        while (current != nullptr) {
            if (current->make == makeLower && current->model == modelLower) {
                break;
            }
            prev = current;
            current = current->next;
        }

        if (current) {
            current->carsNum--;
            cout << "Car is Removed successfully!" << endl;
        } else {
            cout << "Car not found!" << endl;
            return; // go out of the function
        }
        if (current->carsNum == 0) {
            if (prev == nullptr) {
                head = current->next;
            } else {
                prev->next = current->next;
            }
            delete current;
        }

    }

    void print() {
        CarNode* temp = head;
        if(!temp){
            cout<<"No cars in the list."<<endl;
            return;
        }
        cout<<"List of Cars:"<<endl;
        while(temp) {
            cout << "Make: " << temp->make << ", Model: " << temp->model << ", Quantity: "<< temp->carsNum << endl;
            temp = temp->next;
        }
    }

};

#endif /* TASK1_BACKEND_H */
